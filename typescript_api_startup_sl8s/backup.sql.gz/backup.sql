DROP TABLE IF EXISTS "users";
DROP SEQUENCE IF EXISTS users_id_seq;
CREATE SEQUENCE users_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 START 3 CACHE 1;

CREATE TABLE "public"."users" (
    "id" integer DEFAULT nextval('users_id_seq') NOT NULL,
    "unique_id" character varying NOT NULL,
    "username" character varying NOT NULL,
    "created_at" timestamp DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "users_pkey" PRIMARY KEY ("id", "unique_id")
) WITH (oids = false);

TRUNCATE "users";
INSERT INTO "users" ("id", "unique_id", "username", "created_at") VALUES
(1,	'9ac307f5-f85b-4b45-a990-743fa0d1e59c',	'q',	'2025-04-22 10:44:27.122889'),
(2,	'8c23f644-58af-4be5-abcb-5ffe2982fa99',	'qw',	'2025-04-22 10:44:27.122889');
